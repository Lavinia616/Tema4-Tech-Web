#TOPIC: REACT

# Dată fiind aplicația modificati codul sursă astfel încât:

- Aplicația se desenează fără eroare; (0.5 pts)
- Se desenează o componentă RobotForm; (0.5 pts)
- RobotForm are input-urile pentru `name`, `type` și `mass` (0.5 pts)
- Dat fiind că input-urile pentru proprietățile robotului au id-urile `name`, `type` and `mass` și că butonul de adăugare are valoarea `add` se poate adăuga un robot;(0.5 pts)
- După adaugăre, câmpurile formularului sunt readuse la starea inițială (0.5 pts)