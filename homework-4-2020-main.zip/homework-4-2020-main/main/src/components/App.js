import RobotList from './RobotList'

function App () {
  return (
      <div>
      	A list of robots
      	<RobotList />
      </div>
  )
}

export default App
